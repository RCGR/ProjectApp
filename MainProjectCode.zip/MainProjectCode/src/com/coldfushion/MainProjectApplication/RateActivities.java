package com.coldfushion.MainProjectApplication;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by ceesjan on 22-5-2015.
 */
public class RateActivities extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rateactivities_layout);
    }
}